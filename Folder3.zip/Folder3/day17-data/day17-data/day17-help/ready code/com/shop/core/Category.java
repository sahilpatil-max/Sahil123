package com.shop.core;

public enum Category {
	BREAD, BISCUITS, OIL, GRAIN, SPICES, FRUITS
}
