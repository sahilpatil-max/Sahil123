package custom_exceptions;

@SuppressWarnings("serial")
public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
