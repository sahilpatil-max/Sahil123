package com.app.banking;

public enum AcType {
	SAVING, CURRENT, FD, LOAN, DMAT
}
