package com.app.fruits;

public class Fruit {
	private String name;
	
	public Fruit(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
