package com.app.fruits;

public class KashmiriApple extends Apple {
	public KashmiriApple(String name) {
		super(name);
	}
}
