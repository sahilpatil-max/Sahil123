package com.app.core;

public enum Category {
	PETROL, DIESEL, CNG, EV, HYBRID
}
