package var_args;

public class Dog extends Animal {
	public Dog(String name) {
		super(name);
	}
}
