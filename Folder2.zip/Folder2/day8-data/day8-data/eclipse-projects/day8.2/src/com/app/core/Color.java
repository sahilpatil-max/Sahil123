package com.app.core;

public enum Color {
	WHITE, GREY, SILVER, BLACK, RED
}
