package com.app.core;

public interface Stack {
	//data member : public static final
	int STACK_SIZE=2;
	//methods : public abstract
	void push(Customer ref);
	Customer pop();

}
