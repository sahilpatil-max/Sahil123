package dao;

import pojos.Course;

public interface ICourseDao {
//launch new course
	String launchNewCourse(Course course);
}
