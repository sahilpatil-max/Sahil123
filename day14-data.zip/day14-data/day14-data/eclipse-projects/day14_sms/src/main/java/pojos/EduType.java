package pojos;

public enum EduType {
	CBSC, HSC, DEGREE, DIPLOMA
}
