import React from 'react';

export default function FooterComponent() {
  return (
    <footer className='footer'>
      {console.log('4444444444444444444')}
      <span className='text-muted'>All Rights Reserved @Developers.com</span>
    </footer>
  );
}
