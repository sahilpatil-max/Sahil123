package inheritance;

public class TestConstrInvocation {

	public static void main(String[] args) {
		C c1=new C();

	}

}
