package inheritance;

public class B extends A
{
	B()
	{
		//super();
		System.out.println("In B");
	}
}
