package inheritance;

public class A /*extends Object*/
{
	A()
	{
		//super(); //added only in the sub class ctor
		System.out.println("In A");
	}
}
