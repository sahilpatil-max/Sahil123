package p1;

public interface Printer {
	//javac implicitly adds : public static final
	int SPEED=100;
	//method : public abstract
	void print(String mesg);

}
