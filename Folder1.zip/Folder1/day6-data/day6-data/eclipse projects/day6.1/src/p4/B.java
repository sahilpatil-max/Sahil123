package p4;

public interface B {
	int DATA=2345;
	int add(double a,double b);

}
