package p5;

public interface C extends A,B{
 double sum(double a ,double b);
}
