package p5;

public class D implements C{

	@Override
	public boolean test(int num) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double sum(double a, double b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
