package p5;

public interface A {
 void show();
}
