package p2;

public interface B {
	int DATA=2345;
	double add(double a,double b);

}
