package p2;

public interface A {
	int DATA=1234;
	double add(double a,double b);

}
