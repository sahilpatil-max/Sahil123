/*
Objective :  Create a java appln to sum 2 nums , (using cmd line arguments) on the console.

*/

class Sum

{
	 public static void main(String[] ss) //cmd line args
	 {
		 System.out.println("Sum ,"+(ss[0]+ss[1]));
	 }
}