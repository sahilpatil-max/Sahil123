class A{
}
public class B{
}
/*public*/ class C{
}