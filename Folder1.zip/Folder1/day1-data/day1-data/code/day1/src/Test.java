class A{
}
public class B{
}
class C{
}