package com.app.service;

import com.app.dto.TopicDTO;

public interface ITopicService {
	TopicDTO addTopic(TopicDTO topic);
}
